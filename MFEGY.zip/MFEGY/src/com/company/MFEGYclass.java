package com.company;

public class MFEGYclass {
    private double EgyütthatóA;
    private double a;
    private double b;
    private double c;
    private double d;
    private int GyökökSzáma;
    private double x1;
    private double x2;

    public MFEGYclass(String sor){
        String[] st = sor.replace(',','.').split("\\s+");
        this.a = Double.parseDouble(st[0]);
        this.b = Double.parseDouble(st[1]);
        this.c = Double.parseDouble(st[2]);
    }

    public void setA(double a) throws Exception {
        if(a != 0){
            this.EgyütthatóA = a;
        } else {
            throw new Exception("\" Az 'a' együttható nem lehet nulla!\"");
        }
    }

    public double getD(){
        this.d = Math.sqrt(this.b) - (4*this.a*this.c);
        return this.d;
    }

    public int getGyökökSzáma(){
        if(this.d < 0){
            this.GyökökSzáma = 0;
        }
        if(this.d == 0) {
            this.GyökökSzáma = 1;
        }
        if(this.d > 0){
            this.GyökökSzáma = 2;
        }
        return this.GyökökSzáma;
    }

    public double getX1(){
        this.x1 = (-this.b+Math.sqrt(this.d)) / (2*this.a);
        return this.x1;
    }
    public double getX2(){
        this.x2 = (-this.b-Math.sqrt(this.d)) / (2*this.a);
        return this.x2;
    }

    //@Override
    //public String toString(){
        //return String.format("%a %b %c %d", this.a,this.b,this.c,this.d);
    //}
}
