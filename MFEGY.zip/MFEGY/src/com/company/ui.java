package com.company;

import com.company.MFEGYclass;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class ui extends JFrame {
    private Container container;
    private JButton button_load;
    private JPanel panelHibak, panelEgyenlet, panelAdatok;
    private JList listHibak, listEgyenlet;
    private JLabel labelEgyenlet, labelA, labelB, labelC, labelDis, labelGyok, labelX1, labelX2;
    private DefaultListModel dlmHibak, dlmEgyenlet;
    private JFileChooser fileChooser;
    private ArrayList<MFEGYclass> lista;

    public ui(){
        init();
    }

    public void init(){
        this.setTitle("MFEGY - Másodkofú egyenletek gyökei");
        this.setSize(800,600);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.container = this.getContentPane();
        this.setLayout(null);

        this.button_load = new JButton("Adatok betöltése");
        this.button_load.setBounds(20, 20, 300, 30);
        this.button_load.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadData(e);
            }
        });
        this.container.add(this.button_load);

        this.panelHibak = new JPanel();
        this.panelHibak.setLayout(null);
        this.panelHibak.setBounds(20, 70, 700, 150);
        this.panelHibak.setBorder(new TitledBorder("Hibák a kiválasztott állományban"));
        this.container.add(this.panelHibak);

        this.dlmHibak = new DefaultListModel();
        this.listHibak = new JList(dlmHibak);
        this.listHibak.setBounds(20,30,650,100);
        JScrollPane listScroller = new JScrollPane(this.listHibak);
        listScroller.setPreferredSize(new Dimension(650,300));
        this.panelHibak.add(this.listHibak);

        this.panelEgyenlet = new JPanel();
        this.panelEgyenlet.setLayout(null);
        this.panelEgyenlet.setBounds(20, 240, 340, 300);
        this.panelEgyenlet.setBorder(new TitledBorder("Egyenletek"));
        this.container.add(this.panelEgyenlet);


        this.dlmEgyenlet = new DefaultListModel();
        this.listEgyenlet = new JList(dlmEgyenlet);
        this.listEgyenlet.setBounds(20,30,300,250);
        JScrollPane listScroller2 = new JScrollPane(this.listEgyenlet);
        listScroller2.setPreferredSize(new Dimension(650,300));
        this.panelEgyenlet.add(this.listEgyenlet);
        this.listEgyenlet.addListSelectionListener( new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent lse) {
                setData(lse);
            }
        });

        this.panelAdatok = new JPanel();
        this.panelAdatok.setLayout(null);
        this.panelAdatok.setBounds(380, 240, 300, 300);
        this.panelAdatok.setBorder(new TitledBorder("Kiválasztott egyenlet megoldása"));
        this.container.add(panelAdatok);

        this.labelEgyenlet = new JLabel("Egyenlet:");
        this.labelEgyenlet.setBounds(20, 20, 300, 30);
        this.panelAdatok.add(labelEgyenlet);

        this.labelA = new JLabel("a = ");
        this.labelA.setBounds(20, 50, 300, 30);
        this.panelAdatok.add(labelA);

        this.labelB = new JLabel("b = ");
        this.labelB.setBounds(20, 80, 300, 30);
        this.panelAdatok.add(labelB);

        this.labelC = new JLabel("c = ");
        this.labelC.setBounds(20, 110, 300, 30);
        this.panelAdatok.add(labelC);

        this.labelDis = new JLabel("Diszkrimináns = ");
        this.labelDis.setBounds(20, 140, 300, 30);
        this.panelAdatok.add(labelDis);

        this.labelGyok = new JLabel("Valós gyökök száma: ");
        this.labelGyok.setBounds(20, 170, 300, 30);
        this.panelAdatok.add(labelGyok);

        this.labelX1 = new JLabel("X1 = ");
        this.labelX1.setBounds(20, 200, 300, 30);
        this.panelAdatok.add(labelX1);

        this.labelX2 = new JLabel("X2 = ");
        this.labelX2.setBounds(20, 230, 300, 30);
        this.panelAdatok.add(labelX2);

        this.setVisible(true);
    }

    public void loadData(ActionEvent e){
        this.fileChooser = new JFileChooser();
        if (fileChooser.showDialog(this, "Fájl megnyitása") != -1){
            readFile(fileChooser.getSelectedFile().toString());
        }
    }

    public void readFile(String fileName){
        dlmHibak.clear();
        dlmEgyenlet.clear();

        lista = new ArrayList<>();
        try{
            FileReader file = new FileReader(fileName);
            BufferedReader br = new BufferedReader(file);
            String line = br.readLine();
            int num = 1;
            while(line != null){
                try {
                    MFEGYclass mfegy = new MFEGYclass(line);
                    lista.add(mfegy);
                    dlmEgyenlet.addElement(mfegy.toString());
                    line = br.readLine();
                }
                catch (Exception e){
                    dlmHibak.addElement(e.getMessage());
                    line = br.readLine();
                }
            }
            br.close();
            file.close();
        }
        catch (Exception e){
            e.getMessage();
        }
    }

    public void setData(ListSelectionEvent lse){
        this.labelEgyenlet.setText(lse.toString());
    }
}
